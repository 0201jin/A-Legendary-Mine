// Fill out your copyright notice in the Description page of Project Settings.


#include "MyCustomAsset.h"

UMyCustomAsset::UMyCustomAsset()
{

}