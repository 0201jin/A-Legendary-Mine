// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "ALegendaryMineGameModeBase.h"
#include "Player/MyPlayerController.h"
#include "Player/PlayerPawn.h"

AALegendaryMineGameModeBase::AALegendaryMineGameModeBase()
{
	//DefaultPawnClass = APlayerPawn::StaticClass();
	//PlayerControllerClass = AMyPlayerController::StaticClass();
	//HUDClass = AMyHUD::StaticClass();
	//GameStateClass = AMyGameStateBase::StaticClass();
}